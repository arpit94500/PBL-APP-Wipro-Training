
public class Main {

	public static void main(String[] args) {
		
		Apple a = new Apple("Apple","Sweet","moderate");
		a.eat();
		Orange o = new Orange("Orange","Sorrow","moderate");
		o.eat();
	}

}
