
class Apple extends Fruit 
{
	public Apple(String name, String taste, String size) {
		super(name, taste, size);
		// TODO Auto-generated constructor stub
	}

	void eat()
	{
		System.out.println("The name of the fruit is:"+name);
		System.out.println("The taste of fruit is:"+taste);
	}
}
