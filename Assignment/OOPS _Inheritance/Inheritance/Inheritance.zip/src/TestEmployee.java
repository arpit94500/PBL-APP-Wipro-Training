
public class TestEmployee {

	public static void main(String[] args) {
		Employee e =  new Employee("Arpit",2000000.86,2017,"AEEPC4523D");
		System.out.println(e.getName());
		System.out.println(e.getAnnualSalary());
		System.out.println(e.getYear());
		System.out.println(e.getiNo());
		
	}

}
