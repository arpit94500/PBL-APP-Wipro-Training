package School;

class Person {
	private String name;
	private String dateofBirth;
	String getName() {
		return name;
	}
	void setName(String name) {
		this.name = name;
	}
	String getDateofBirth() {
		return dateofBirth;
	}
	void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
}
