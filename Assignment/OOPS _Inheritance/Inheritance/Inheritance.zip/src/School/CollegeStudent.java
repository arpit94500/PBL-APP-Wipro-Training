package School;

 class CollegeStudent extends Student {
	 private String collegeName;
	 private String year;
	String getCollegeName() {
		return collegeName;
	}
	void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	String getYear() {
		return year;
	}
	void setYear(String year) {
		this.year = year;
	}
	 

}
