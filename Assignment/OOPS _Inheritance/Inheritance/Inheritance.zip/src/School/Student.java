package School;

class Student extends Person{
	private int sId;

	int getsId() {
		return sId;
	}

	void setsId(int sId) {
		this.sId = sId;
	}
}
