
public class Animal {
	void eat()
	{
		System.out.println("Animal Eat");
	}
	void sleep()
	{
		System.out.println("Animal sleep");
	}
}
