
public class Bird extends Animal {
	void eat()
	{
		System.out.println("Birds eat");
	}
	void sleep()
	{
		System.out.println("Birds sleep");
	}
	void fly()
	{
		System.out.println("Birds Fly");
	}
}
