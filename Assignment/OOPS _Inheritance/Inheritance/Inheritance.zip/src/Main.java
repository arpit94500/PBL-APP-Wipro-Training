
public class Main {

	public static void main(String[] args) {
		Animal a = new Animal();
		a.eat();
		a.sleep();
		Bird b = new Bird();
		b.eat();
		b.sleep();
		b.fly();

	}

}
