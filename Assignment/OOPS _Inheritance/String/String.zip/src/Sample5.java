
public class Sample5 {

	public static void main(String[] args) {
		String s ="Suman";
		System.out.println(s.substring(1,s.length()-1));

	}

}
