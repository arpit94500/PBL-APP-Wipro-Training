
public class Sample19 {

	public static void main(String[] args) {
		int i=0;
		int n=2*3*5;
		int t=n;
		while(i<5)
		{
			if(t%n==0)
			{
				System.out.println(t);
				i++;
			}
			
				t++;
	
		}
	}

}
