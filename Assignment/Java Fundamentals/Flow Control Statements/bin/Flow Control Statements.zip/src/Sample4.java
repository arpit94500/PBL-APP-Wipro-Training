
public class Sample4 {

	public static void main(String[] args) {
		char a = args[0].charAt(0);
		char b = args[1].charAt(0);
		int c = a;
		int d = b;
		if(c<d)
		{
			System.out.println(a+","+b);
		}
		else
			System.out.println(b+","+a);
		
		
		
		

	}

}
