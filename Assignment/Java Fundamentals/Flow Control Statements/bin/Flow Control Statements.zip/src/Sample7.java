
public class Sample7 {

	public static void main(String[] args) {
		char a='a';
		if(a>=65 && a<=90)
		{
			System.out.println((char)(a+32));
		}
		else
			System.out.println((char)(a-32));

	}

}
